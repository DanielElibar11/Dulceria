<footer class="main-footer">
	
	<strong>Copyright &copy; 2023 <a href="https://www.instagram.com/daniel_eliruz/" target=" blank">BETAS</a>.
	</strong>

	Todos los derechos reservados.

</footer>